CREATE VIEW fenshu AS
  SELECT
    `Emploee`.`emp`.`empno`    AS `empno`,
    `Emploee`.`emp`.`ename`    AS `ename`,
    `Emploee`.`emp`.`job`      AS `job`,
    `Emploee`.`emp`.`mgr`      AS `mgr`,
    `Emploee`.`emp`.`hiredate` AS `hiredate`,
    `Emploee`.`emp`.`sal`      AS `sal`,
    `Emploee`.`emp`.`comm`     AS `comm`,
    `Emploee`.`emp`.`deptno`   AS `deptno`,
    `Emploee`.`test`.`NAME`    AS `NAME`
  FROM `Emploee`.`emp`
    JOIN `Emploee`.`test`;

